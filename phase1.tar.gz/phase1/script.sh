#!/bin/bash

umount -r /home/mount1/dir1/
gcc -Wall hello.c `pkg-config fuse3 --cflags --libs` -o hello
./hello /home/mount1/dir1/
cat /home/mount1/dir1/hello

