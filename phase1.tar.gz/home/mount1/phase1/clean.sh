#!/bin/bash

umount -r /home/mount1/dir1/
rm -rf hello

